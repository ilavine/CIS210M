"""
Program Name:   timer_countdown.py


Writen by:      Iuliia Lavine


Date:           07 September 2020


Synopsis:      This is a countdown timer. 
               It imports the libraries time and datetime.
               A user needs to input time in seconds to initiate the countdown. 
               The loop will break once the loop reaches 0. 
"""





import time
import datetime


t = int(input('Input time in seconds for countdown: '))

while t > 0:
    
    print("{}".format(str(datetime.timedelta(seconds=t))))
    time.sleep(1)
    print('\n')
    t -= 1
        
print('Time is up')