import time
import datetime


t = int(input('Input time in seconds for countdown: '))

while t > 0:
    
    print("{}".format(str(datetime.timedelta(seconds=t))))
    time.sleep(1)
    print('\n')
    t -= 1
        
print('Time is up')