import time

start = input('Press 1 to start timing. Exit the loop with CTRL+C:')

if start == '1':
    timer = True
    
    
sec = 0
min = 0

timer = start

try:
    while True:
        sec += 1
        print(str(min) + " minute(s)" + str(sec) + " second(s)")
        time.sleep(1)
        if sec == 60:
            sec = 0
            min += 1
            print(str(min) + " minute(s)" + str(sec) + " second(s)")
            
except KeyboardInterrupt:
    print('Timing has stopped at' + str(min) + ' minutes' + str(sec) + ' seconds')